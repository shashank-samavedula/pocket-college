import React from 'react'
import { View, Text, Button } from 'react-native'

const Detail = ({ navigation }) => {
    return (
        <View>
            <Text>Detail</Text>
            <Button title="Go to home" onPress={() => navigation.navigate('Home')} />
        </View>
    )
}

export default Detail

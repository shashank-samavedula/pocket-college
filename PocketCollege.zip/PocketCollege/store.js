import { applyMiddleware, combineReducers, createStore  } from "redux";
import { composeWithDevTools } from "redux-devtools-extension";
import thunk from "redux-thunk";

import userInfoReducer from './src/reducers/UserInfo';

const middleware = applyMiddleware(composeWithDevTools(thunk));

const rootReducer = combineReducers({
    user: userInfoReducer
});

export default createStore(rootReducer, {}, middleware);
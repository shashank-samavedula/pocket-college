import React, { useState, useEffect } from 'react';
import { Text, StyleSheet, Button, View, TouchableOpacity } from 'react-native';
import Icon from 'react-native-vector-icons/Ionicons';
import MaterialIcons from 'react-native-vector-icons/MaterialIcons';

import { RTCPeerConnection, RTCView, mediaDevices, RTCIceCandidate, RTCSessionDescription } from 'react-native-webrtc';
import { db } from '../utilities/firebase';

const configuration = {
  iceServers: [
    {
      urls: ['stun:stun1.l.google.com:19302', 'stun:stun2.l.google.com:19302'],
    },
  ],
  iceCandidatePoolSize: 10,
};

export default function JoinScreen({ setScreen, screens, roomId }) {

  function onBackPress() {
    if (cachedLocalPC) {
      cachedLocalPC.removeStream(localStream);
      cachedLocalPC.close();
    }
    setLocalStream();
    setRemoteStream();
    setCachedLocalPC();
    // cleanup
    setScreen(screens.ROOM);
  }

  const [localStream, setLocalStream] = useState();
  const [remoteStream, setRemoteStream] = useState();
  const [cachedLocalPC, setCachedLocalPC] = useState();

  const [videoOn, setVideoOn] = useState(true);
  const [showCaller, setShowCaller] = useState(true);
  const [isMuted, setIsMuted] = useState(false);

  const [firstTime, setFirstTime] = useState(true);

  useEffect(() => {
    startLocalStream();
  }, []);

  const startLocalStream = async () => {
    // isFront will determine if the initial camera should face user or environment
    const isFront = true;
    const devices = await mediaDevices.enumerateDevices();
  
    const facing = isFront ? 'front' : 'environment';
    const videoSourceId = devices.find(device => device.kind === 'videoinput' && device.facing === facing);
    const facingMode = isFront ? 'user' : 'environment';
    
     const constraints = {
      audio: true,
      video: {
        mandatory: {
          minWidth: 500, // Provide your own width, height and frame rate here
          minHeight: 300,
          minFrameRate: 30,
        },
        facingMode,
        optional: videoSourceId ? [{ sourceId: videoSourceId }] : [],
      }
    };
    
    const newStream = await mediaDevices.getUserMedia(constraints);
    setLocalStream(newStream);
    setVideoOn(!videoOn)
  };

  const endLocalStream = async () => {

     const constraints = {
      audio: true,
      video: false
    };

    const newStream = await mediaDevices.getUserMedia(constraints);
    setLocalStream(newStream);
    setVideoOn(!videoOn)
  }

  const joinCall = async id => {
    const roomRef = await db.collection('rooms').doc(id);
    const roomSnapshot = await roomRef.get();

    if (!roomSnapshot.exists) return
    const localPC = new RTCPeerConnection(configuration);
    localPC.addStream(localStream);

    const calleeCandidatesCollection = roomRef.collection('calleeCandidates');
    localPC.onicecandidate = e => {
      if (!e.candidate) {
        console.log('Got final candidate!');
        return;
      }
      calleeCandidatesCollection.add(e.candidate.toJSON());
    };

    localPC.onaddstream = e => {
      if (e.stream && remoteStream !== e.stream) {
        console.log('RemotePC received the stream join', e.stream);
        setRemoteStream(e.stream);
      }

      setFirstTime(false);
    };

    const offer = roomSnapshot.data().offer;
    await localPC.setRemoteDescription(new RTCSessionDescription(offer));

    const answer = await localPC.createAnswer();
    await localPC.setLocalDescription(answer);

    const roomWithAnswer = { answer };
    await roomRef.update(roomWithAnswer);

    roomRef.collection('callerCandidates').onSnapshot(snapshot => {
      snapshot.docChanges().forEach(async change => {
        if (change.type === 'added') {
          let data = change.doc.data();
          await localPC.addIceCandidate(new RTCIceCandidate(data));
        }
      });
    });

    setCachedLocalPC(localPC);
  };

  const switchCamera = () => {
    localStream.getVideoTracks().forEach(track => track._switchCamera());
  };

  // Mutes the local's outgoing audio
  const toggleMute = () => {
    console.log(remoteStream)
    if (!remoteStream) {
      return;
    }
    localStream.getAudioTracks().forEach(track => {
      // console.log(track.enabled ? 'muting' : 'unmuting', ' local track', track);
      track.enabled = !track.enabled;
      setIsMuted(!track.enabled);
    });
  };

  return (
    <View style={{flex:1}}>
      <Text style={styles.heading} >Join Screen</Text>
      <Text style={styles.heading} >Room : {roomId}</Text>

      <View style={{padding: 10, alignItems:'center'}} >
        {showCaller ? (
          <View style={styles.rtcview}>
          {/* caller/You */}
          {localStream && <RTCView style={styles.rtc} streamURL={localStream && localStream.toURL()} />}
        </View>
        ) : (
          <View style={styles.rtcview}>
            {/* callee/The other person */}
            {remoteStream && <RTCView style={styles.rtc} streamURL={remoteStream && remoteStream.toURL()} />}
          </View>
        )}

        <View style={{flexDirection:'row', margin:10, width:'100%', justifyContent:'space-evenly'}}>
          <TouchableOpacity onPress={onBackPress}
            style={{paddingHorizontal:10, height:50, justifyContent:'center', alignItems:'center', borderRadius:30, backgroundColor:'tomato'}}>
              <Icon name="log-out-outline" color="#fff" size={30} />
            </TouchableOpacity>
    
          {videoOn ? (
            <TouchableOpacity onPress={startLocalStream}
            style={{paddingHorizontal:10, height:50, justifyContent:'center', alignItems:'center', borderRadius:30, backgroundColor:'green'}}>
                <MaterialIcons name="videocam" color="#fff" size={30} />
              </TouchableOpacity>
          ) : (
            <TouchableOpacity onPress={endLocalStream}
            style={{paddingHorizontal:10, height:50, justifyContent:'center', alignItems:'center', borderRadius:30, backgroundColor:'green'}}>
                <MaterialIcons name="videocam-off" color="#fff" size={30} />
              </TouchableOpacity>
          )}

            <TouchableOpacity style={{paddingHorizontal:10, height:50, justifyContent:'center', alignItems:'center', borderRadius:30, backgroundColor:'skyblue'}}
              onPress={switchCamera}>
              <MaterialIcons name="repeat" color="#fff" size={30} />
            </TouchableOpacity>

            {firstTime === true ? (
              <TouchableOpacity onPress={() => joinCall(roomId)}
              style={{ height:50, justifyContent:'center', alignItems:'center', borderRadius:30, backgroundColor:'gold', paddingHorizontal:15}}>
                <Text style={{color:'#fff', fontWeight:'bold'}}>On audio</Text>
            </TouchableOpacity>
            ) : (
              <TouchableOpacity onPress={toggleMute}
                style={{height:50, justifyContent:'center', alignItems:'center', borderRadius:30, backgroundColor:'gold', paddingHorizontal:10}}>
                {isMuted == false ? (
                  <Icon name="mic-off-sharp" color="#fff" size={30} />
                  ) : (
                    <Icon name="mic-sharp" color="#fff" size={30} />
                )}
              </TouchableOpacity>
            )}
          
        </View>
        <View style={{ flexDirection:'row', width:'100%'}}>
          {showCaller ? (
            <TouchableOpacity onPress={() => setShowCaller(false)}>
              <View style={styles.rtcview2}>
                {/* callee/The other person */}
                  {remoteStream && <RTCView style={styles.rtc} streamURL={remoteStream && remoteStream.toURL()} />}
              </View>
            </TouchableOpacity>
          ) : (
            <TouchableOpacity onPress={() => setShowCaller(!showCaller)}>
              <View style={styles.rtcview2}>
                {/* caller/You */}
                {localStream && <RTCView style={styles.rtc} streamURL={localStream && localStream.toURL()} />}
              </View>
            </TouchableOpacity>
          )}
        </View>
      </View>

    </View>
  )
}

const styles = StyleSheet.create({
  heading: {
    alignSelf: 'center',
    fontSize: 30,
  },
  rtcview: {
    // flex: 1,
    backgroundColor: 'black',
    margin: 5,
    width:350,
    height:350,
    borderRadius:20
  },
  rtcview2: {
    // flex: 1,
    backgroundColor: 'white',
    margin: 5,
    height:100,
    width:90,
    borderRadius:15
  },
  rtc: {
    // flex: 1,
    width: '100%',
    height: '100%',
  },
  toggleButtons: {
    width: '100%',
    flexDirection: 'row',
    justifyContent: 'space-around',
  },
  callButtons: {
    padding: 10,
    width: '100%',
    flexDirection: 'row',
    justifyContent: 'space-around',
  },
  buttonContainer: {
    margin: 5,
  }
});


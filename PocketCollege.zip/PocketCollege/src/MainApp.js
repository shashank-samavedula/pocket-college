import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import Ionicons from "react-native-vector-icons/Ionicons";

import AssignmentSection from './tabs/AssignmentSection';
import AttendenceSection from './tabs/attendenceScreen/AttendenceSection';
import Video from './tabs/Video';
import ChatFeature from './tabs/chats/ChatFeature'
import FeedsFeature from './tabs/feeds/FeedsFeature';


const Tab = createBottomTabNavigator();

function MyTabs() {
  return (
    <Tab.Navigator
      initialRouteName="Feed"
      screenOptions={{
        tabBarActiveTintColor: '#fff',
        tabBarInactiveTintColor:"#737373",
        tabBarStyle: { borderTopWidth:0 }
      }}
    >
      <Tab.Screen
        name="Feeds"
        component={FeedsFeature}
        options={{
          tabBarLabel: 'Home',
          headerShown:false,
          headerStyle:{backgroundColor:'#131820'},
          tabBarActiveBackgroundColor:'#131820',
          tabBarInactiveBackgroundColor:'#131820',
          tabBarIcon: ({ color, size }) => (
            <Ionicons name="home-sharp" color={color} size={22} />
          ),
        }}
      />
      <Tab.Screen
        name="Chats"
        component={ChatFeature}
        options={{
          tabBarLabel: 'Chats',
          headerShown:false,
          tabBarActiveBackgroundColor:'#131820',
          tabBarInactiveBackgroundColor:'#131820',
          tabBarIcon: ({ color, size }) => (
            <Ionicons name="chatbubbles-sharp" color={color} size={22} />
          ),
        }}
      />
      <Tab.Screen
        name="Assignment"
        component={AssignmentSection}
        options={{
          tabBarLabel: 'Assignment',
          headerShown:false,
          tabBarActiveBackgroundColor:'#131820',
          tabBarInactiveBackgroundColor:'#131820',
          tabBarIcon: ({ color, size }) => (
            <Ionicons name="book" color={color} size={22} />
          ),
        }}
      />

      <Tab.Screen
        name="Attendence"
        component={AttendenceSection}
        options={{
          tabBarLabel: 'Attendence',
          headerShown:false,
          tabBarActiveBackgroundColor:'#131820',
          tabBarInactiveBackgroundColor:'#131820',
          tabBarIcon: ({ color, size }) => (
            <Ionicons name="hand-right" color={color} size={22} />
          ),
        }}
      />

      <Tab.Screen
        name="Video"
        component={Video}
        options={{
          tabBarLabel: 'Video Call',
          headerShown:false,
          tabBarActiveBackgroundColor:'#131820',
          tabBarInactiveBackgroundColor:'#131820',
          tabBarIcon: ({ color, size }) => (
            <Ionicons name="videocam" color={color} size={22} />
          ),
        }}
      />
    </Tab.Navigator>
  );
}

export default function MainApp() {
  
  return (
    <NavigationContainer>
      <MyTabs />
    </NavigationContainer>
  )
}

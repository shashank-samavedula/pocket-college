import { SET_USER, GET_USER } from "../constants";

const initialState = {
    user: null
}

export default UserInfo = (state = initialState, action) => {
    const { type, payload } = action;
    switch (type) {
        case SET_USER:
            return{
                ...state,
                user: payload
            }
        case GET_USER:
            return {
                ...state,
                user: payload
            }
        default:
            return{
                ...state
            }
    }
}
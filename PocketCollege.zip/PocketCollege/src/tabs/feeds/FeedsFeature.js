import React from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

import FeedScreen from './Feed';
import AddPostScreen from './AddPost';

const Stack = createNativeStackNavigator();

const FeedsFeature = () => {
    return (
        <Stack.Navigator>
            <Stack.Screen name="Feed" component={FeedScreen} options={{ title: "Daily Feeds",headerTintColor: '#fff', headerStyle: { backgroundColor: "#131820" } }} />
            <Stack.Screen name="AddPost" component={AddPostScreen} options={{ title: "Add post",headerTintColor: '#009394', headerStyle: { backgroundColor: "#131820" } }} />
        </Stack.Navigator>
    )
}

export default FeedsFeature

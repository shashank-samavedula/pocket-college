import React, { useState, useEffect } from 'react';
import { View, Text, StatusBar, Image, StyleSheet, TouchableOpacity, ActivityIndicator, RefreshControl, FlatList } from 'react-native';
import { useSelector, useDispatch } from 'react-redux';
import firestore from '@react-native-firebase/firestore';
import auth from '@react-native-firebase/auth';
import { GET_USER } from '../../constants';

const Feed = ({ navigation }) => {
    const [feeds, setFeeds] = useState([]);
    const [refreshList, setRefreshList] = useState(false);
    const [loading, setLoading] = useState(true);

    const userData = useSelector(state => state.user.user)

    const dispatch = useDispatch();

    useEffect(() => {
        dispatch(getUser())
    }, [dispatch])

    const getUser = () => dispatch => {
    
        firestore()
            .collection("Users")
            .doc(auth().currentUser.uid)
            .get()
            .then((usersnap) => {
                dispatch({ type: GET_USER, payload: usersnap.data() })
                const user = usersnap.data()
                dailyFeeds(user.college, user.branch)
                setLoading(false)
            })
    }

    const dailyFeeds = (college, branch) => {
        setFeeds([]);
        firestore()
            .collection(college)
            .doc(branch)
            .collection("Feeds")
            .get()
            .then((snapshot) => {
                snapshot.docs.map(doc => {
                    setFeeds(oldFeeds => [...oldFeeds, doc.data()])
                })
            })
    }

    const dates = (num) => {
        var d = new Date(num);
        var monthArray = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];

        var dateFormatted = monthArray[d.getMonth()] + ' ' + d.getDate();
        return dateFormatted;
    }

    const onRefreshList = () => {
        setRefreshList(true)
        dailyFeeds(userData.college, userData.branch)
        setRefreshList(false)
    }

    if(loading == true && feeds.length == 0){
        return(
            <View>
                <ActivityIndicator color="#1d242f" size='large' />
            </View>
        )
    }

    if(loading == false && feeds.length == 0){
        return(
            <View style={styles.container}>
                <Text style={styles.caption}>List is empty</Text>
            </View>
        )
    }

    return (
        <View style={styles.container}>
            <StatusBar backgroundColor="#131820" barStyle='light-content' />

            <FlatList
                    refreshControl={
                        <RefreshControl
                        refreshing={refreshList}
                        onRefresh={onRefreshList}
                        />
                    }
                    data={feeds}
                    keyExtractor={item => item.time}
                    renderItem={({item}) => (

                <View style={{justifyContent: 'center', alignItems: 'center' }}>

                    <View style={{flexDirection:'row', marginVertical:25}}>
                        <View style={{width:50, height:50, backgroundColor:'gold', borderRadius:30, justifyContent:'center', alignItems:'center'}}>
                            <Text style={{color:'#1d242f', fontWeight:'bold'}}>You</Text>
                        </View>
                        <View style={{marginLeft:10}}>
                        <View style={{flexDirection:'row'}}>
                        <Text style={{color:'#fff', fontWeight:'bold', marginBottom:15}}>{item.username}   •   </Text>
                        <Text style={{color:'#fff', marginBottom:15}}>{dates(item.time)}</Text>
                        </View>
                        {item.caption ? (
                            <Text style={styles.caption}>{item.caption}</Text>
                        ) : null}
                        {item.img ? (
                            <Image source={{uri: item.img}} style={styles.img}/>
                        ) : null}
                        </View>
                    </View>

                    <View style={styles.line}></View>
                </View>
                )}
            />


            {userData.userStatus != "Student" ? (

                <View style={{position:'absolute'}}>
                    <TouchableOpacity onPress={() => navigation.navigate('AddPost')}
                    style={styles.addBtn}>
                    <Text style={styles.addPost}>+</Text>
                </TouchableOpacity>
            </View>
            ) : null}
        </View>
    )
}

const styles = StyleSheet.create({
    container:{
        flex:1,
        backgroundColor:"#1d242f",
    },
    img:{
        width:310,
        height:310,
        borderRadius:25,
    },
    line: {
        width:'93%',
        height:1,
        backgroundColor:'#999999'
    },
    addBtn:{
        width:60,
        height:60,
        backgroundColor:"#4857fa",
        marginTop:590,
        marginLeft:300,
        justifyContent:'center',
        alignItems:'center',
        borderRadius:30
    },
    addPost:{
        color:"#fff",
        fontWeight:'bold',
        fontSize:35
    },
    caption: {
        color:"#fff",
        padding:10,
        fontWeight:'500',
        fontSize:15
    }
})

export default Feed

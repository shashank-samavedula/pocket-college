import React,{ useState } from 'react';
import { View, Text, StyleSheet, TextInput, TouchableOpacity, Image, Alert } from 'react-native';
import { useSelector } from 'react-redux';
import ImagePicker from 'react-native-image-crop-picker';
import storage from '@react-native-firebase/storage';
import firestore from '@react-native-firebase/firestore';

const AddPost = ({ navigation }) => {
    const [caption, setCaption] = useState("");
    const [image, setImage] = useState("");

    const user = useSelector(state => state.user.user)

    const pickImage = () => {
        ImagePicker.openPicker({
            width: 400,
            height: 400,
            cropping: true
          }).then(image => {
                console.log(image.path);
                setImage(image.path)
        }).catch(err => {
              console.log(err);
          })
    }

    const post = () => {
        if(image.length > 0){

            const uploadTask = storage().ref().child(`/userprofile/${Date.now()}`).putFile(image)
                uploadTask.on('state_changed',
                    (snapshot) => {
                        var progress = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
                        if(progress==100) Alert.alert("Image Uploaded")
                    },
                    (error) => {
                        Alert.alert("Error")
                    },
                    () => {
                        uploadTask.snapshot.ref.getDownloadURL().then((downloadURL) => {
                            console.log("File available at", downloadURL);
                            setImage(downloadURL);
                            firestore()
                                .collection(user.college)
                                .doc(user.branch)
                                .collection("Feeds")
                                .add({
                                    img: downloadURL,
                                    caption: caption,
                                    username: user.name,
                                    userid: user.userid,
                                    time: new Date().getTime()
                                })
                                .then(() => {
                                    navigation.navigate('Feed')
                                })
                        })
                    }
                )
        }
        else if(caption.length > 0){
            firestore()
                .collection(user.college)
                    .doc(user.branch)
                    .collection("Feeds")
                    .add({
                        img: null,
                        caption: caption,
                        username: user.name,
                        userid: user.userid,
                        time: new Date().getTime()
                    })
                    .then(() => {
                        navigation.navigate('Feed')
                    })
        }
        else{
            Alert.alert("Nothing to post")
        }
    }

    return (
        <View style={styles.container}>
            {image.length > 0 ? (
                <Image source={{uri : image}} style={{width:100, height:100}} />
            ) : null}
            <TextInput
                            style={[
                                styles.input,
                                {
                                    height:150,
                                    paddingVertical: 10,
                                    textAlignVertical: 'top'
                                }
                            ]}
                            multiline={true}
                            placeholder={'Type here!'}
                            value={caption}
                            onChangeText={(text) => setCaption(text)}
                        />

            <TouchableOpacity onPress={() => pickImage()} style={styles.btn}>
                <Text style={styles.txt}>Upload Picture</Text>
            </TouchableOpacity>
            <TouchableOpacity onPress={() => post()} style={styles.btn}>
                <Text style={styles.txt}>Post</Text>
            </TouchableOpacity>
        </View>
    )
}

const styles = StyleSheet.create({
    container: {
        flex:1,
        backgroundColor:"#1d242f",
        alignItems:'center'
    },
    input: {
        width: "90%",
        height:44,
        backgroundColor:"#fff",
        borderRadius: 20,
        paddingHorizontal: 10,
        marginVertical:15,
    },
    btn: {
        width:150,
        height:50,
        backgroundColor: "#4857fa",
        borderRadius:25,
        alignItems:'center',
        justifyContent:'center',
        marginTop:10
    },
    txt: {
        color:"#fff",
        fontWeight:"bold"
    }
})

export default AddPost

import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, Button, TouchableOpacity, Linking, Dimensions, ActivityIndicator, Alert, Image } from 'react-native';
import firestore from '@react-native-firebase/firestore';
import storage from '@react-native-firebase/storage';
import DocumentPicker from 'react-native-document-picker';
import { Platform } from 'react-native';
import RNFetchBlob from 'rn-fetch-blob';
import Pdf from 'react-native-pdf';

const SubmitAssignment = ({ route }) => {
    const {subject, user, item} = route.params;
    const [assignmentDetail, setAssignmentDetail] = useState(null);

    useEffect(() => {
        getData()
    }, [])

    const getData = async() => {
        await firestore()
            .collection(user.college)
            .doc(user.branch)
            .collection("Assignments")
            .doc(user.sem+"")
            .collection(user.sem+"-semester")
            .doc(subject)
            .collection(subject)
            .doc(item.id+"")
            .collection("submitted")
            .doc(user.userid+"")
            .get()
            .then((snapshot) => {
                if(snapshot.data()){
                    setAssignmentDetail(snapshot.data());
                }
                else{
                }
            })
    }

    async function chooseFile() {
        //Pick a single file
        try{
            const file = await DocumentPicker.pick({
                type: [DocumentPicker.types.allFiles],
            });

            if(file[0].type == "application/pdf"){

                const path = await normalizePath(file[0].uri)
                const result = await RNFetchBlob.fs.readFile(path, 'base64')
                // console.log(result)
                uploadFileToFirebaseStorage(result, file);
            }
            else{
                Alert.alert("Please select pdf format")
            }

        } catch (err) {
            if(DocumentPicker.isCancel(err)){
                //User cancelled the picker
            }
            else{
                throw err;
            }
        }
    }

    async function normalizePath(path){
        if(Platform.OS === 'ios' || Platform.OS === 'android'){
            const filePrefix = 'file://';
            if(path.startsWith(filePrefix)){
                path = path.substring(filePrefix.length);
                try{
                    path = decodeURI(path)
                } catch (e) {}
            }
        }

        return path;
    }

    async function uploadFileToFirebaseStorage(result, file){
        const uploadTask = storage().ref(`documents/${file[0].name}`).putString(result,'base64', {contentType:file[0].type});

        uploadTask.on('state_changed',
            (snapshot) => {
                // Get task progress, including the number of bytes uploaded and the total number of bytes to be uploaded
                const progress = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
                console.log('Upload is ' + progress + '% done');
                switch (snapshot.state) {
                case 'paused':
                    console.log('Upload is paused');
                    break;
                case 'running':
                    console.log('Upload is running');
                    break;
                }
            }, 
            (error) => {
                switch (error.code) {
                case 'storage/unauthorized':
                    // User doesn't have permission to access the object
                    break;
                case 'storage/canceled':
                    // User canceled the upload
                    break;

                // ...

                case 'storage/unknown':
                    // Unknown error occurred, inspect error.serverResponse
                    break;
                }
            }, 
            () => {
                // Upload completed successfully, now we can get the download URL
                uploadTask.snapshot.ref.getDownloadURL().then((downloadURL) => {
                console.log('File available at', downloadURL);
                firestore()
                    .collection(user.college)
                    .doc(user.branch)
                    .collection("Assignments")
                    .doc(user.sem+"")
                    .collection(user.sem+"-semester")
                    .doc(subject)
                    .collection(subject)
                    .doc(item.id+"")
                    .collection("submitted")
                    .doc(user.userid+"")
                    .set({
                        studentId:user.userid,
                        studentName: user.name,
                        fileUrl:downloadURL,
                        time: new Date().getTime()
                    })
                });
            }
        );
    }

    const dates = (num) => {
        var d = new Date(num);
        var monthArray = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];

        var dateFormatted = monthArray[d.getMonth()] + ' ' + d.getDate();
        return dateFormatted;
    }

    return (
        <View style={styles.container}>
            <Image source={require('../../../../img/img1.jpg')} style={styles.img} />
            {assignmentDetail !== null ? (
                <>
                    <Text style={{color:"#fff", marginVertical:3, backgroundColor:'#4da6ff', paddingHorizontal:10, borderRadius:10}}>{dates(assignmentDetail.time)}</Text>
                    <View style={{flexDirection:'row'}}>
                    <Text style={styles.txt}>Assignment submitted : </Text>
                        <TouchableOpacity
                                onPress={() => {Linking.openURL(assignmentDetail.fileUrl)}}>
                            <Text style={{color:"skyblue", fontSize:20, fontWeight:'bold'}}>Open Pdf File</Text>
                        </TouchableOpacity>
                    </View>
                </>

            ) : null}

            <TouchableOpacity style={styles.btn} onPress={() => chooseFile()}>
                <Text style={{color:"#fff", fontSize:20, fontWeight:'bold'}}>Upload File</Text>
            </TouchableOpacity>
            {/* <Pdf source={{ uri: 'https://firebasestorage.googleapis.com/v0/b/signuprnfb.appspot.com/o/documents%2F3.%20React%20Native%20Mobile%20Application%20Developer.pdf?alt=media&token=782446a4-f5b0-40db-88d7-f88a8d9d12b8'}}
                style={styles.pdf} /> */}
        </View>
    )
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor:'#1d242f',
        alignItems:'center'
    },

    pdf: {
        flex:1,
        width:Dimensions.get('window').width,
        height:Dimensions.get('window').height,
    },

    img: {
        marginVertical:20,
        width:"90%",
        height:"35%",
        borderRadius:20
    },
    btn: {
        width:"50%",
        height:55,
        backgroundColor:"#1a75ff",
        justifyContent:'center',
        alignItems:'center',
        borderRadius:30,
        marginVertical:20
    },

    txt: {
        color:"#fff",
        fontSize:20,
        fontWeight:'bold'
    }
})

export default SubmitAssignment

import React from 'react';
import { View, Text, Image, TouchableOpacity, StyleSheet, Linking } from 'react-native';

const CheckAssignment = ({ route }) => {
    const { item } = route.params;

    const dates = (num) => {
        var d = new Date(num);
        var monthArray = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];

        var dateFormatted = monthArray[d.getMonth()] + ' ' + d.getDate();
        return dateFormatted;
    }

    return (
        <View style={styles.container}>
            <Image source={require('../../../../img/img1.jpg')} style={styles.img} />
            <Text style={{color:"#fff", marginVertical:3, backgroundColor:'#4da6ff', paddingHorizontal:10, borderRadius:10}}>{dates(item.time)}</Text>
            <View style={{flexDirection:'row'}}>
                <Text style={styles.txt}>Assignment submitted : </Text>
                    <TouchableOpacity
                            onPress={() => {Linking.openURL(item.fileUrl)}}>
                        <Text style={{color:"skyblue", fontSize:20, fontWeight:'bold'}}>Open Pdf File</Text>
                    </TouchableOpacity>
            </View>

            <Text style={styles.name}>Student's Name : {item.studentName}</Text>
        </View>
    )
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor:'#1d242f',
        alignItems:'center'
    },

    img: {
        marginVertical:20,
        width:"90%",
        height:"35%",
        borderRadius:20
    },
    btn: {
        width:"50%",
        height:55,
        backgroundColor:"#1a75ff",
        justifyContent:'center',
        alignItems:'center',
        borderRadius:30,
        marginVertical:20
    },

    txt: {
        color:"#fff",
        fontSize:20,
        fontWeight:'bold'
    },

    name: {
        color:"#fff",
        fontSize:20,
        fontWeight:'bold',
        padding:10
    }
})

export default CheckAssignment

import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, TextInput, TouchableOpacity, FlatList, RefreshControl, ActivityIndicator } from 'react-native';
import firestore from '@react-native-firebase/firestore';

const AssignmentTeachers = ({ route, navigation }) => {
    const { sem, subject, user } = route.params;
    const [list, setList] = useState([]);
    const [refreshList, setRefreshList] = useState(false);

    useEffect(() => {
        getData()
    }, [])

    const onRefreshList = () => {
        setRefreshList(true)
        getData()
        setRefreshList(false)
    }

    const getData = () => {
        setList([])
        firestore()
            .collection(user.college)
            .doc(user.branch)
            .collection("Assignments")
            .doc(sem+"")
            .collection(sem+"-semester")
            .doc(subject)
            .collection(subject)
            .get()
            .then((snapshot) => {
                snapshot.forEach((doc) => {
                    let id = doc.id;
                    let docData = doc.data()
                    docData = {...docData, id}
                    setList(list => [...list, docData])
                })
            })

    }

    if(list.length == 0){
        return(
            <View style={styles.container}>
                <ActivityIndicator color="#fff" size='large' />
            </View>
        )
    }

    return (
        <View style={styles.container}>

                <FlatList
                    refreshControl={
                        <RefreshControl
                        refreshing={refreshList}
                        onRefresh={onRefreshList}
                        />
                    }
                    data={list}
                    keyExtractor={item => item.time}
                    renderItem={({item}) => (
                        <TouchableOpacity style={styles.item} onPress={() => navigation.navigate('AllSubmittedAssignments', { sem:sem, subject:subject, user:user, item:item } )}>
                            <View style={styles.box}></View>
                            <Text style={{color:"#fff"}}>{item.assignment}</Text>
                        </TouchableOpacity>
                    )}
                />
        </View>
    )
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor:'#1d242f',
        alignItems:'center'
    },
    btn2: {
        width:"85%", height:60, backgroundColor:'#009394',
        borderRadius:30,
        justifyContent:'center',
        alignItems:'center',
        marginLeft:20
    },
    input: {
        width:"75%",
        height:60,
        borderRadius:30,
        borderWidth:1.5,
        borderColor:"#009394",
        paddingLeft:15,
        color:"#fff"
    },
    box: {
        width:15, height:15, borderColor:'#009394', borderRadius:3,
        borderWidth:2,
        marginLeft:15,
        marginRight:10
    },
    item:{
        flexDirection:'row',width:360, backgroundColor:"#27303f", marginVertical:10, paddingVertical:15,
        borderRadius:5,
        alignItems:'center'
    }
})

export default AssignmentTeachers

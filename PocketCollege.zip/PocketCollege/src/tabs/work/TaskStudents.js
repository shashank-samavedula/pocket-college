import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, FlatList, RefreshControl, ActivityIndicator } from 'react-native';
import firestore from '@react-native-firebase/firestore';
import { useSelector } from 'react-redux';

const TaskStudents = () => {
    const user = useSelector(state => state.user.user)
    const [list, setList] = useState([]);
    const [refreshList, setRefreshList] = useState(false);

    useEffect(() => {
        getData()
    }, [])

    const onRefreshList = () => {
        setRefreshList(true)
        getData()
        setRefreshList(false)
    }

    const getData = () => {
        setList([])
        firestore()
            .collection(user.college)
            .doc(user.branch)
            .collection("Tasks")
            .doc(user.sem+"")
            .collection("Task")
            .get()
            .then((snapshot) => {
                snapshot.forEach((doc) => {
                    setList(list => [...list, doc._data])
                })
            })

    }

    if(list.length == 0){
        return(
            <View style={styles.container}>
                <ActivityIndicator color="#fff" size='large' />
            </View>
        )
    }

    return (
        <View style={styles.container}>

                <FlatList
                    refreshControl={
                        <RefreshControl
                        refreshing={refreshList}
                        onRefresh={onRefreshList}
                        />
                    }
                    data={list}
                    keyExtractor={item => item.time}
                    renderItem={({item}) => (
                        <View style={styles.item}>
                            <View style={styles.box}></View>
                            <View>
                            <Text style={{color:"#fff"}}>{item.assignedBy}</Text>
                            <Text style={{color:"#fff"}}>{item.task}</Text>
                            </View>
                        </View>
                    )}
                />
        </View>
    )
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor:'#1d242f',
        alignItems:'center'
    },
    btn2: {
        width:60, height:60, backgroundColor:'#009394',
        borderRadius:30,
        justifyContent:'center',
        alignItems:'center',
        marginLeft:20
    },
    input: {
        width:"75%",
        height:60,
        borderRadius:30,
        borderWidth:1.5,
        borderColor:"#009394",
        paddingLeft:15,
        color:"#fff"
    },
    box: {
        width:15, height:15, borderColor:'#009394', borderRadius:3,
        borderWidth:2,
        marginLeft:15,
        marginRight:10
    },
    item:{
        flexDirection:'row',width:360, backgroundColor:"#27303f", marginVertical:10, paddingVertical:15,
        borderRadius:5,
        alignItems:'center'
    }
})

export default TaskStudents

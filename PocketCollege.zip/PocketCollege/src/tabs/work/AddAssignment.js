import React,{ useState } from 'react';
import { View, Text, StyleSheet, TextInput, TouchableOpacity, Image, Alert } from 'react-native';
import firestore from '@react-native-firebase/firestore';

const AddAssignment = ({ navigation, route }) => {

    const { sem, user } = route.params;
    const [subject, setSubject] = useState("");
    const [assignment, setAssignment] = useState("");

    const addTask = () => {
        if(subject.length > 0 && assignment.length > 0){
            firestore()
                .collection(user.college)
                .doc(user.branch)
                .collection("Assignments")
                .doc(sem+"")
                .collection(sem+"-semester")
                .doc(subject)
                .set({})
                .then(() => {
                    firestore()
                        .collection(user.college)
                        .doc(user.branch)
                        .collection("Assignments")
                        .doc(sem+"")
                        .collection(sem+"-semester")
                        .doc(subject)
                        .collection(subject)
                        .add({
                            assignment: assignment,
                            time: new Date().getTime()
                        })
                    Alert.alert("Assignment Posted!")
                    navigation.goBack()
                })
        }
    }

    return (
        <View style={styles.container}>
            <TextInput placeholder="Write your notes here!" placeholderTextColor="#d3d3d3"
                    style={styles.input1} value={subject} onChangeText={(text) => setSubject(text)} />
            <TextInput
                            style={[
                                styles.input,
                                {
                                    height:150,
                                    paddingVertical: 10,
                                    textAlignVertical: 'top'
                                }
                            ]}
                            multiline={true}
                            placeholder={'Type here!'}
                            value={assignment}
                            onChangeText={(text) => setAssignment(text)}
                        />

            <TouchableOpacity style={styles.btn} onPress={() => addTask()}>
                <Text style={styles.txt}>Post</Text>
            </TouchableOpacity>
        </View>
    )
}

const styles = StyleSheet.create({
    container: {
        flex:1,
        backgroundColor:"#1d242f",
        alignItems:'center'
    },
    input: {
        width: "90%",
        height:44,
        backgroundColor:"#fff",
        borderRadius: 20,
        paddingHorizontal: 10,
        marginVertical:15,
    },
    btn: {
        width:150,
        height:50,
        backgroundColor: "#4857fa",
        borderRadius:25,
        alignItems:'center',
        justifyContent:'center',
        marginTop:10
    },
    txt: {
        color:"#fff",
        fontWeight:"bold"
    },
    input1: {
        width:"90%",
        height:60,
        borderRadius:30,
        borderWidth:1.5,
        borderColor:"#009394",
        paddingLeft:15,
        color:"#fff"
    },
})

export default AddAssignment

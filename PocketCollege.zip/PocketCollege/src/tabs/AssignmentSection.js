import * as React from 'react';
import { createMaterialTopTabNavigator } from '@react-navigation/material-top-tabs';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

import Assignment from './work/Assignment';
import SemAssignment from './work/SemAssignment';
import AssignmentTeachers from './work/assign/AssignmentTeachers';
import AddAssignment from './work/AddAssignment';
import AllSubmittedAssignments from './work/assign/AllSubmittedAssignments';
import CheckAssignment from './work/assign/CheckAssignment';

import TaskScreen from './work/Task';
import AssignTask from './work/AssignTask';

import NotesScreen from './work/Notes';


const Tab = createMaterialTopTabNavigator();
const Stack = createNativeStackNavigator();

export default function AssignmentSection() {
  return (
    <Tab.Navigator>
        <Tab.Screen name="AssignmentScreen" component={AssignmentScreen} options={{ title:"Assignments", tabBarStyle: { backgroundColor:"#131820" }, tabBarActiveTintColor: '#009394' }} />
        <Tab.Screen name="AssignTaskScreen" component={AssignTaskScreen} options={{ title:"Tasks", tabBarStyle: { backgroundColor:"#131820" }, tabBarActiveTintColor: '#009394' }} />
        <Tab.Screen name="Notes" component={NotesScreen} options={{ title:"Notes 📝", tabBarStyle: { backgroundColor:"#131820" }, tabBarActiveTintColor: '#009394' }} />
  </Tab.Navigator>
  );
}

function AssignmentScreen(){
  return(
    <Stack.Navigator>
      <Stack.Screen name="Assignment" component={Assignment} options={{headerShown:false}} />
      <Stack.Screen name="SemAssignment" component={SemAssignment} options={{headerShown:false}} />
      <Stack.Screen name="AddAssignment" component={AddAssignment} options={{headerShown:false}} />
      <Stack.Screen name="AssignmentTeachers" component={AssignmentTeachers} options={{headerShown:false}} />
      <Stack.Screen name="AllSubmittedAssignments" component={AllSubmittedAssignments} options={{headerShown:false}} />
      <Stack.Screen name="CheckAssignment" component={CheckAssignment} options={{headerShown:false}} />
    </Stack.Navigator>
  )
}

function AssignTaskScreen(){
  return(
    <Stack.Navigator>
      <Stack.Screen name="Task" component={TaskScreen} options={{ headerShown:false}} />
      <Stack.Screen name="AssignTask" component={AssignTask} options={{headerShown:false}} />
    </Stack.Navigator>
  )
}
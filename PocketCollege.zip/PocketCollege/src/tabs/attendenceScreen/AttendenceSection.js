import * as React from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { useSelector } from 'react-redux';

import Attendence from './teachers/Attendence';
import TakeAttendence from './teachers/TakeAttendence';
import CreateClass from './teachers/CreateClass';
import Requests from './teachers/Requests';

import AttendenceList from './students/AttendenceList';
import GiveAttendence from './students/GiveAttendence';

const Stack = createNativeStackNavigator();

export default function AttendenceSection(){
    const user = useSelector(state => state.user.user);

    if(user.userStatus == 'Student'){
        return(
        <Stack.Navigator initialRouteName="AttendenceList">
            <Stack.Screen name="AttendenceList" component={AttendenceList} options={{ title:"Attendence", headerStyle:{ backgroundColor:"#131820" }, headerTintColor:"#fff" }} />
            <Stack.Screen name="GiveAttendence" component={GiveAttendence} options={{ headerShown:false}} />
        </Stack.Navigator>
        )
    }
    
    return(
        <Stack.Navigator initialRouteName="Attendence">
            <Stack.Screen name="Attendence" component={Attendence} options={{ headerShown:false}} />
            <Stack.Screen name="TakeAttendence" component={TakeAttendence} options={{ title:"Subjects", headerStyle:{ backgroundColor:"#1d242f" }, headerTintColor:"#fff" }} />
            <Stack.Screen name="CreateClass" component={CreateClass} options={{ headerShown:false}} />
            <Stack.Screen name="Requests" component={Requests} options={{ title:"Requests", headerStyle:{ backgroundColor:"#131820" }, headerTintColor:"#fff" }} />
        </Stack.Navigator>
    )
}

import React from 'react';
import { View, Text } from 'react-native';

const GiveAttendence = () => {
    return (
        <View>
            <Text>give attendence</Text>
        </View>
    )
}

export default GiveAttendence

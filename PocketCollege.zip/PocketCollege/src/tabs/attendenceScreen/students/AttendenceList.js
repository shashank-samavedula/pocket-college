import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, TextInput, TouchableOpacity, Alert, RefreshControl, ActivityIndicator, Button, FlatList } from 'react-native';
import Icon from 'react-native-vector-icons/Ionicons';
import firestore from '@react-native-firebase/firestore';
import auth from '@react-native-firebase/auth';
import { useSelector } from 'react-redux';

const AttendenceList = () => {
    const user = useSelector(state => state.user.user);
    const [subjects, setSubjects] = useState([]);
    const [refreshList, setRefreshList] = useState(false);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        getSubjects();
    }, [])

    const signout = () => {
        auth()
          .signOut()
      }

    const getSubjects = () => {
        setSubjects([])
        firestore()
            .collection(user.college)
            .doc(user.branch)
            .collection("Attendence")
            .doc(user.sem+"")
            .collection(user.sem+"-semester")
            .get()
            .then((snapshot) => {
                snapshot.docs.map((doc) => {
                    setSubjects(subject => [...subject, doc.data()])
                })
            })
    }

    const present = (subject) => {
        firestore()
            .collection(user.college)
            .doc(user.branch)
            .collection("Attendence")
            .doc(user.sem+"")
            .collection(user.sem+"-semester")
            .doc(subject)
            .collection("Requests")
            .doc(user.userid)
            .set({
                name:user.name,
                time: new Date().getTime(),
                userId: user.userid
            })
    }

    return (
        <View style={styles.container}>
            <FlatList
                data={subjects}
                keyExtractor={item => item.subject}
                renderItem={({item}) => (
                    <View style={styles.box}>
                        <View style={{flexDirection:"row", paddingBottom:15}}>
                            <View style={styles.profile}></View>
                            <View>
                            <Text style={{color:"#fff", fontSize:19, fontWeight:"bold"}}>{item.teacher}</Text>
                            <Text style={{color:"#fff", fontSize:16, fontWeight:"bold"}}>Subject : {item.subject}</Text>
                            </View>
                        </View>
                        <View style={{paddingHorizontal:20}}>
                        <Button title="Send request" onPress={() => present(item.subject)} />
                        </View>
                    </View>
                )}
            />
            <Button title="Logout" onPress={() => signout()} />
        </View>
    )
}

const styles = StyleSheet.create({
    container:{
        flex: 1,
        alignItems: 'center',
        backgroundColor:'#1d242f'
    },

    box: {
        width:350,
        paddingVertical:15,
        backgroundColor:"#27303f",
        justifyContent:'center',
        borderRadius:15,
        marginVertical:10
    },
    profile: {
        width: 50,
        height: 50,
        backgroundColor:"#fff",
        borderRadius:25,
        marginRight:15,
        marginLeft:25
    }
})

export default AttendenceList

import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Alert, RefreshControl, FlatList, ActivityIndicator } from 'react-native';
import Icon from 'react-native-vector-icons/Ionicons';
import firestore from '@react-native-firebase/firestore';

const Requests = ({ route }) => {
    const { subject, sem, user } = route.params;
    const [list, setList] = useState([]);
    const [refreshList, setRefreshList] = useState(false);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        requestList();
    }, [])

    const requestList = () => {
        setList([])
        firestore()
            .collection(user.college)
            .doc(user.branch)
            .collection("Attendence")
            .doc(sem+"")
            .collection(sem+"-semester")
            .doc(subject)
            .collection("Requests")
            .get()
            .then((snapshot) => {
                if(snapshot.docs.length > 0){
                    snapshot.docs.forEach((doc) => {
                        setList(prevList => [...prevList, doc.data()])
                    })
                }
            })
    }

    const setStudent = (item) => {
        firestore()
            .collection("Users")
            .doc(item.userId)
            .get()
            .then((snapshot) => {
                accept(snapshot.data().college, snapshot.data().branch, item)
            })
    }

    const rejectStudent = (item) => {
        firestore()
            .collection("Users")
            .doc(item.userId)
            .get()
            .then((snapshot) => {
                reject(snapshot.data().college, snapshot.data().branch, item)
            })
    }

    const accept = (college, branch, item) => {
        let num = new Date().getTime();
        var d = new Date(num);
        var monthArray = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
    
        var dateFormatted = monthArray[d.getMonth()] + ' ' + d.getDate() + ' ' + d.getFullYear();

        firestore()
            .collection(college)
            .doc(branch)
            .collection("Student")
            .doc(sem+"")
            .collection("Student-Data")
            .doc(item.userId+"")
            .collection(subject+"-Attendence")
            .doc(dateFormatted+"")
            .set({})
            .then(() => {
                firestore()
                    .collection(college)
                    .doc(branch)
                    .collection("Attendence")
                    .doc(sem+"")
                    .collection(sem+"-semester")
                    .doc(subject)
                    .collection("Requests")
                    .doc(item.userId+"")
                    .delete()
                    .then(() => {
                        requestList()
                    })
            })
                
    }

    const reject = (college, branch, item) => {
        firestore()
            .collection(college)
            .doc(branch)
            .collection("Attendence")
            .doc(sem+"")
            .collection(sem+"-semester")
            .doc(subject)
            .collection("Requests")
            .doc(item.userId+"")
            .delete()
            .then(() => {
                requestList()
            })
    }

    const datesss = (n) => {
        var d = new Date(n);
        var monthArray = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
    
        var dateFormatted = monthArray[d.getMonth()] + ' ' + d.getDate() + ' ' + d.getFullYear();
        return dateFormatted;
    }

    const onRefreshList = () => {
        setRefreshList(true)
        requestList()
        setRefreshList(false)
    }

    return (
        <View style={styles.container}>
            {list.length > 0 ? (
                <FlatList
                    refreshControl={
                        <RefreshControl
                        refreshing={refreshList}
                        onRefresh={onRefreshList}
                        />
                    }
                    data={list}
                    keyExtractor={item => item.userId}
                    renderItem={({item}) => (
                        <View style={styles.box}>
                            <View style={{flexDirection:'row',alignItems:"center"}}>
                                <View style={styles.profile}></View>
                                <View>
                                    <Text style={{color:"#fff", fontSize:18, fontWeight:'bold'}}>{item.name}</Text>
                                    <Text style={{color:"#fff", fontWeight:'bold'}}>{datesss(item.time)} hours ago</Text>
                                </View>
                            </View>

                            <View>
                                <View style={{flexDirection:'row', justifyContent:'space-around'}}>
                                    <TouchableOpacity style={styles.box1} onPress={() => setStudent(item)}>
                                        <Icon name="checkmark-sharp" color="#2eb82e" size={30} />
                                    </TouchableOpacity>

                                    <TouchableOpacity style={styles.box2} onPress={() => rejectStudent(item)}>
                                        <Icon name="close-sharp" color="tomato" size={30} />
                                    </TouchableOpacity>
                                </View>
                            </View>
                        </View>
                    )}
                />
            ) : (
                <Text style={{color:"#fff", fontSize:18, fontWeight:"bold", marginTop:30}}>Empty</Text>
            )}
        </View>
    )
}

const styles = StyleSheet.create({
    container:{
        flex: 1,
        alignItems: 'center',
        backgroundColor:'#1d242f'
    },

    box: {
        width:350,
        backgroundColor:"#27303f",
        justifyContent:'center',
        borderRadius:15,
        marginVertical:10,
        paddingVertical:20
    },
    item: {
        paddingHorizontal:15
    },
    profile: {
        width: 50,
        height: 50,
        backgroundColor:"#fff",
        borderRadius:25,
        marginRight:15,
        marginLeft:25
    },
    box1: {
        paddingHorizontal:40,
        paddingVertical:7,
        marginTop:10,
        borderWidth:2,
        borderColor:"#2eb82e",
        borderRadius:30
    },
    box2: {
        paddingHorizontal:40,
        paddingVertical:7,
        marginTop:10,
        borderWidth:2,
        borderColor:"tomato",
        borderRadius:30
    }
})

export default Requests

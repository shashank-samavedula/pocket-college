import React, { useState } from 'react';
import { View, Text, StyleSheet, TextInput, TouchableOpacity, Alert } from 'react-native';
import Icon from 'react-native-vector-icons/Ionicons';
import firestore from '@react-native-firebase/firestore';

const CreateClass = ({ route, navigation }) => {
    const { user } = route.params;
    const [sem, setSem] = useState(5);
    const [branch, setBranch] = useState(["EEE", "CSE", "ET&T", "CIVIL", "MECH", "IT"]);
    const [num, setNum] = useState(0);
    const [subject, setSubject] = useState("");

    const attendence = () => {
        if(subject.length > 0){
            firestore()
                .collection(user.college)
                .doc(user.branch)
                .collection("Subject")
                .doc(sem+"")
                .collection("Subject")
                .doc(subject)
                .set({
                    subject: subject
                })
                .then(() => {
                    Alert.alert("New Class Created.")
                    navigation.navigate('Attendence')
                })
        }
    }

    return (
        <View style={styles.container}>
            <TextInput placeholder="Your Subject" placeholderTextColor="#fff" style={styles.input} value={subject} onChangeText={(txt) => setSubject(txt)} />
    
            <View style={{flexDirection:'row'}}>

                {sem > 1 ? (
                    <TouchableOpacity onPress={() => setSem(sem - 1)}>
                        <Icon name="chevron-back-circle-sharp" color="#fff" size={45} />
                    </TouchableOpacity>
                ) : (
                        <Icon name="chevron-back-circle-outline" color="#fff" size={45} />
                )}

                <Text style={{color:"#fff", fontSize:30, fontWeight:"bold", marginHorizontal:15}}>Sem : {sem}</Text>
                
                {sem < 8 ? (
                    <TouchableOpacity onPress={() => setSem(sem + 1)}>
                        <Icon name="chevron-forward-circle-sharp" color="#fff" size={45} />
                    </TouchableOpacity>
                    ) : (
                        <Icon name="chevron-forward-circle-outline" color="#fff" size={45} />
                        )}
            </View>

            <View style={{flexDirection:'row'}}>

                {num > 0 ? (
                    <TouchableOpacity onPress={() => setNum(num - 1)}>
                        <Icon name="chevron-back-circle-sharp" color="#fff" size={45} />
                    </TouchableOpacity>
                ) : (
                        <Icon name="chevron-back-circle-outline" color="#fff" size={45} />
                )}

                <View style={{width:130, alignItems:'center'}}>
                <Text style={{color:"#fff", fontSize:30, fontWeight:"bold", fontStyle:'italic', paddingHorizontal:20}}>{branch[num]}</Text>
                </View>
                
                {num < 5 ? (
                    <TouchableOpacity onPress={() => setNum(num + 1)}>
                        <Icon name="chevron-forward-circle-sharp" color="#fff" size={45} />
                    </TouchableOpacity>
                    ) : (
                        <Icon name="chevron-forward-circle-outline" color="#fff" size={45} />
                        )}
            </View>

            <TouchableOpacity style={styles.btn} onPress={() => attendence()}>
                <Text style={{color:"#fff", fontSize:18, fontWeight:"bold"}}>Take Attendence</Text>
            </TouchableOpacity>

        </View>
    )
}

const styles = StyleSheet.create({
    container:{
        flex: 1,
        alignItems: 'center',
        backgroundColor:'#1d242f',
    },
    input: {
        width:"89%",
        height:45,
        borderWidth:2,
        borderColor:"#3a485f",
        color:"#fff",
        marginVertical:20,
        paddingHorizontal:10,
        backgroundColor:'#303c4f',
        borderRadius:7
    },
    btn: {
        width:"55%",
        height:60,
        backgroundColor: "#4857fa",
        borderRadius:30,
        alignItems:"center",
        justifyContent:"center",
        marginTop:20
    }
})

export default CreateClass

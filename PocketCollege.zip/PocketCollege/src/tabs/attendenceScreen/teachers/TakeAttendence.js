import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Alert, RefreshControl, FlatList, ActivityIndicator } from 'react-native';
import Icon from 'react-native-vector-icons/Ionicons';
import firestore from '@react-native-firebase/firestore';
import { useSelector } from 'react-redux';

const TakeAttendence = ({ route, navigation }) => {
    const { sem } = route.params;
    const user = useSelector(state => state.user.user);
    const [subjects, setSubjects] = useState([]);
    const [refreshList, setRefreshList] = useState(false);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        getSubjects();
    }, [])

    const getSubjects = () => {
        setSubjects([])
        firestore()
            .collection(user.college)
            .doc(user.branch)
            .collection("Subject")
            .doc(sem+"")
            .collection("Subject")
            .get()
            .then((snapshot) => {
                snapshot.docs.map((doc) => {
                    setSubjects(subject => [...subject, doc.data()]);
                })
                setLoading(false);
            })
    }

    const attendence = (subject) => {
        firestore()
            .collection(user.college)
            .doc(user.branch)
            .collection("Attendence")
            .doc(sem+"")
            .collection(sem+"-semester")
            .doc(subject)
            .set({
                subject: subject,
                time: new Date().getTime(),
                teacher: user.name,
                teacherId: user.userid
            })
            .then(() => {
                firestore()
                    .collection(user.college)
                    .doc(user.branch)
                    .collection("Attendence")
                    .doc(sem+"")
                    .collection(sem+"-semester")
                    .doc(subject)
                    .collection("Requests")
                    .get()
                    .then((snapshot) => {
                        snapshot.docs.map((doc) => {
                            let data = doc.data()
                            firestore()
                                .collection(user.college)
                                .doc(user.branch)
                                .collection("Attendence")
                                .doc(sem+"")
                                .collection(sem+"-semester")
                                .doc(subject)
                                .collection("Requests")
                                .doc(data.userId)
                                .delete()
                        })
                    })
                Alert.alert("Posted")
                totalClasses(subject)
            })
    }

    const totalClasses = (subject) => {

        let num = new Date().getTime();
        var d = new Date(num);
        var monthArray = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
    
        var dateFormatted = monthArray[d.getMonth()] + ' ' + d.getDate() + ' ' + d.getFullYear();

        firestore()
            .collection(user.college)
            .doc(user.branch)
            .collection("Attendence")
            .doc(sem+"")
            .collection("total-classes")
            .doc("total-classes")
            .collection(subject)
            .doc(dateFormatted+"")
            .set({})
    }

    const deleteDoc = (subject) => {
        firestore()
            .collection(user.college)
            .doc(user.branch)
            .collection("Attendence")
            .doc(sem+"")
            .collection(sem+"-semester")
            .doc(subject)
            .collection("Requests")
            .get()
            .then((snapshot) => {
                snapshot.docs.map((doc) => {
                    let data = doc.data()
                    firestore()
                        .collection(user.college)
                        .doc(user.branch)
                        .collection("Attendence")
                        .doc(sem+"")
                        .collection(sem+"-semester")
                        .doc(subject)
                        .collection("Requests")
                        .doc(data.userId)
                        .delete()
                        .then(() => {
                            firestore()
                                .collection(user.college)
                                .doc(user.branch)
                                .collection("Attendence")
                                .doc(sem+"")
                                .collection(sem+"-semester")
                                .doc(subject)
                                .delete()
                        })
                    })
                })
                Alert.alert("Previous attendence list cleared")
    }

    const deleteSubject = (subject) => {
        firestore()
            .collection(user.college)
            .doc(user.branch)
            .collection("Subject")
            .doc(sem+"")
            .collection("Subject")
            .doc(subject)
            .delete()
            .then(() => {
                getSubjects()
            })
    }

    const onRefreshList = () => {
        setRefreshList(true)
        getSubjects()
        setRefreshList(false)
    }

    if(subjects.length == 0 && loading == true){
        return(
            <View style={styles.container}>
                <ActivityIndicator color="#fff" size='large' />
            </View>
        )
    }

    if(subjects.length == 0 && loading == false){
        return(
            <View style={styles.container}>
                <Text style={{color:"#fff"}}>No subjects!</Text>
            </View>
        )
    }

    return (
        <View style={styles.container}>

            <FlatList
                refreshControl={
                    <RefreshControl
                    refreshing={refreshList}
                    onRefresh={onRefreshList}
                    />
                }
                data={subjects}
                keyExtractor={item => item.subject}
                renderItem={({item}) => (
                    <View style={styles.box}>
                        <Text style={{color:"#fff", fontWeight:"bold", fontSize:17, marginBottom:7}}>Subject : {item.subject}</Text>
                        <View style={{flexDirection:'row'}}>
                            <TouchableOpacity style={styles.item} onPress={() => attendence(item.subject)}>
                            <Icon name="ios-add-circle-sharp" color="#fff" size={30} />
                            </TouchableOpacity>

                            <TouchableOpacity style={styles.item} onPress={() => deleteDoc(item.subject)}>
                            <Icon name="remove-circle-sharp" color="#fff" size={30} />
                            </TouchableOpacity>
                            <TouchableOpacity style={styles.item} onPress={() => navigation.navigate('Requests', { subject: item.subject, sem: sem, user: user })}>
                            <Icon name="people-sharp" color="#fff" size={30} />
                            </TouchableOpacity>
                            <TouchableOpacity style={styles.item} onPress={() => deleteSubject(item.subject)}>
                            <Icon name="trash" color="#fff" size={27} />
                            </TouchableOpacity>
                        </View>
                    </View>
                )}
            />

        </View>
    )
}

const styles = StyleSheet.create({
    container:{
        flex: 1,
        alignItems: 'center',
        backgroundColor:'#1d242f'
    },

    box: {
        width:350,
        backgroundColor:"#27303f",
        alignItems:'center',
        justifyContent:'center',
        borderRadius:15,
        marginVertical:10,
        paddingVertical:20
    },
    item: {
        paddingHorizontal:15
    }
})

export default TakeAttendence

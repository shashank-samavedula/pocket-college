import React,{ useState, useEffect } from 'react';
import { View, Text, Button, StyleSheet, TouchableOpacity } from 'react-native';
import auth from '@react-native-firebase/auth';
import { useSelector } from 'react-redux';

const Attendence = ({ navigation }) => {
    const user = useSelector(state => state.user.user);

    const signout = () => {
        auth()
          .signOut()
      }

    return (
        <View style={styles.container}>
            
            <View style={{flexDirection:'row'}}>
                <TouchableOpacity style={styles.sem} onPress={() => navigation.navigate('TakeAttendence', { sem:8 })}>
                    <Text>8 sem</Text>
                </TouchableOpacity>
                <TouchableOpacity style={styles.sem2} onPress={() => navigation.navigate('TakeAttendence', { sem:7 })}>
                    <Text>7 sem</Text>
                </TouchableOpacity>
            </View>
            <View style={{flexDirection:'row'}}>
                <TouchableOpacity style={styles.sem3} onPress={() => navigation.navigate('TakeAttendence', { sem:6 })}>
                    <Text>6 sem</Text>
                </TouchableOpacity>
                <TouchableOpacity style={styles.sem4} onPress={() => navigation.navigate('TakeAttendence', { sem:5 })}>
                    <Text>5 sem</Text>
                </TouchableOpacity>
            </View>
            <View style={{flexDirection:'row'}}>
                <TouchableOpacity style={styles.sem} onPress={() => navigation.navigate('TakeAttendence', { sem:4 })}>
                    <Text>4 sem</Text>
                </TouchableOpacity>
                <TouchableOpacity style={styles.sem2} onPress={() => navigation.navigate('TakeAttendence', { sem:3 })}>
                    <Text>3 sem</Text>
                </TouchableOpacity>
            </View>
            <View style={{flexDirection:'row'}}>
                <TouchableOpacity style={styles.sem3} onPress={() => navigation.navigate('TakeAttendence', { sem:2 })}>
                    <Text>2 sem</Text>
                </TouchableOpacity>
                <TouchableOpacity style={styles.sem4} onPress={() => navigation.navigate('TakeAttendence', { sem:1 })}>
                    <Text>1 sem</Text>
                </TouchableOpacity>
            </View>



                <Button title="Logout" onPress={() => signout()} /> 
                <View style={{position:'absolute'}}>
                    <TouchableOpacity onPress={() => navigation.navigate('CreateClass', { user: user })}
                    style={styles.addBtn}>
                    <Text style={styles.addPost}>+</Text>
                </TouchableOpacity>
            </View> 
        </View>
    )
}

const styles = StyleSheet.create({
    container:{
        flex: 1,
        alignItems: 'center',
        backgroundColor:'#1d242f',
        paddingTop:10
    },
    addBtn:{
        width:60,
        height:60,
        backgroundColor:"#4857fa",
        marginTop:630,
        marginLeft:280,
        justifyContent:'center',
        alignItems:'center',
        borderRadius:30
    },
    addPost:{
        color:"#fff",
        fontWeight:'bold',
        fontSize:35
    },

    listItem: {
        backgroundColor:'#27303f',
        marginVertical:10,
        width:355,
        height:60,
        borderRadius:10,
        flexDirection:'row',
        alignItems:'center'
    },
    box: {
        width:15, height:15, borderColor:'#009394', borderRadius:3,
        borderWidth:2,
        marginLeft:15
    },
    txt: {
        color:'#fff',
        marginLeft:5
    },
    btn: {
        width:115, height:50, backgroundColor:'#009394',
        borderRadius:30,
        justifyContent:'center',
        alignItems:'center'
    },
    btn2: {
        width:115, height:50, backgroundColor:'#009394',
        borderRadius:30,
        justifyContent:'center',
        alignItems:'center',
        marginLeft:30
    },
    sem:{
        width:"45%",
        height:100,
        backgroundColor:"skyblue",
        margin:7,
        alignItems:'center',
        justifyContent:'center',
        borderRadius:15
    },
    sem2:{
        width:"45%",
        height:100,
        backgroundColor:"#F54768",
        margin:7,
        alignItems:'center',
        justifyContent:'center',
        borderRadius:15
    },
    sem3:{
        width:"45%",
        height:100,
        backgroundColor:"#FFAB41",
        margin:7,
        alignItems:'center',
        justifyContent:'center',
        borderRadius:15
    },
    sem4:{
        width:"45%",
        height:100,
        backgroundColor:"#3B999B",
        margin:7,
        alignItems:'center',
        justifyContent:'center',
        borderRadius:15
    }
})

export default Attendence

import React,{ useState, useEffect } from 'react'
import { View, Text, FlatList, TouchableOpacity, StyleSheet } from 'react-native';
import firestore from '@react-native-firebase/firestore';
import { useSelector } from 'react-redux';

const List = ({ navigation }) => {
    const [user, setUser] = useState(null);
    const [list, setList] = useState([]);

    const userData = useSelector(state => state.user.user);

    useEffect(() => {
        getUser()
        setList([])
        firestore()
            .collection("Users")
            .get()
            .then((snapshot) => {
                snapshot.forEach((doc) => {
                    setList(list => [...list, doc._data])
                })
            })
    }, [])

    const getUser = () => {
        firestore()
            .collection("Users")
            .doc(userData.userid)
            .get()
            .then((snapshot) => {
                setUser(snapshot._data);
            })
    }

    if(!user){
        return(
            <View style={styles.container}>
                <Text style={{color:"white"}}>Loading...</Text>
            </View>
        )
    }

    return (
        <View style={styles.container}>
            {list.length > 0 ? (
                <FlatList
                    data={list}
                    renderItem={({item}) => (
                        <View>
                            {user.name == item.name ? null : (
                                <TouchableOpacity onPress={() => navigation.navigate('Chat', { otherUser:item, loggedInUser:user })} style={styles.contacts}>
                                    <View style={{flexDirection:'row'}}>
                                        <View style={styles.profile}></View>
                                        <View style={{justifyContent:'center', paddingLeft:10}}>
                                            <Text style={styles.names}>{item.name}</Text>
                                        </View>
                                    </View>
                                </TouchableOpacity>
                            )}
                        </View>
                    )}
                />
            ) : null}
        </View>
    )
}

const styles = StyleSheet.create({
    container:{
        flex:1,
        backgroundColor:'#1d242f'
    },
    contacts:{
        borderBottomWidth:0.5,
        borderBottomColor:"#009394",
        paddingVertical:10,
        paddingLeft:15
    },
    profile:{
        width:50, height:50, backgroundColor:"#fff", borderRadius:25
    },
    names:{
        color:"#fff", fontWeight:'bold'
    }
})

export default List

import * as React from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

import ListScreen from './List';
import ChatScreen from './Chat';

const Stack = createNativeStackNavigator();  

const ChatFeature = () => {
  return (
      <Stack.Navigator>
        <Stack.Screen name="List" component={ListScreen} options={{ title: "Recent Chats 📝",headerTintColor: '#009394', headerStyle: { backgroundColor: "#131820" } }} />
        <Stack.Screen name="Chat" component={ChatScreen} options={{ headerTintColor: '#009394', headerStyle: { backgroundColor: "#131820" } }} />
      </Stack.Navigator>
  );
}

export default ChatFeature;
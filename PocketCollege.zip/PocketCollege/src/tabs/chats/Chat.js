import React,{ useState, useEffect } from 'react';
import { View, Text } from 'react-native';
import { GiftedChat, Bubble, InputToolbar } from 'react-native-gifted-chat';
import firestore from '@react-native-firebase/firestore';

const Chat = ({ route }) => {
    const [messages, setMessages] = useState([]);
    const { otherUser, loggedInUser } = route.params;

    useEffect(() => {
        // getAllMessages()

        const docid = loggedInUser.userid > otherUser.userid ? loggedInUser.userid + "-" + otherUser.userid : otherUser.userid + "-" + loggedInUser.userid;
        const messageRef = firestore()
            .collection("chatrooms")
            .doc(docid)
            .collection("messages")
            .orderBy("createdAt", "desc")

        messageRef.onSnapshot((querysnap) => {
            const allmsg = querysnap.docs.map(docsnap => {
                const data = docsnap.data()
                if(data.createdAt){
                    return{
                        ...docsnap.data(),
                        createdAt:docsnap.data().createdAt.toDate()
                    }
                }
                else{
                    return{
                        ...docsnap.data(),
                        createdAt: new Date()
                    }
                }
            })
            setMessages(allmsg)
        })
        
    }, [])

    const getAllMessages = async() => {
        const docid = loggedInUser.userid > otherUser.userid ? loggedInUser.userid + "-" + otherUser.userid : otherUser.userid + "-" + loggedInUser.userid;
        const querySnap = await firestore()
            .collection("chatrooms")
            .doc(docid)
            .collection("messages")
            .orderBy("createdAt", "desc")
            .get()

            const allmsg = querySnap.docs.map(docSnap => {
                return{
                    ...docSnap.data(),
                    createdAt: docSnap.data().createdAt.toDate()
                }
            })
        setMessages(allmsg)
    }

    const onSend = (messageArray) => {
        const msg = messageArray[0];
        const mymsg = {
            ...msg,
            sentBy:loggedInUser.userid,
            sentTo:otherUser.userid,
            createdAt: new Date()
        }

        setMessages(previousMessages => GiftedChat.append(previousMessages, mymsg))
        const docid = loggedInUser.userid > otherUser.userid ? loggedInUser.userid + "-" + otherUser.userid : otherUser.userid + "-" + loggedInUser.userid;
        firestore()
            .collection("chatrooms")
            .doc(docid)
            .collection("messages")
            .add({...mymsg, createdAt: firestore.FieldValue.serverTimestamp()})
    }

    return (
        <View style={{ flex: 1, backgroundColor:'#1d242f' }}>
            <GiftedChat
                messages={messages}
                onSend={messages => onSend(messages)}
                user={{
                    _id: loggedInUser.userid,
                }}
                renderBubble={(props) => {
                    return <Bubble
                        {...props}
                        wrapperStyle={{
                            right: {
                                backgroundColor:"#009394",
                                borderBottomRightRadius:2
                            },
                            left: {
                                backgroundColor:"#d9d9d9",
                                borderBottomLeftRadius:2,
                            }
                        }}
                    />
                }}
                renderInputToolbar={(props) => {
                    return <InputToolbar {...props}
                        containerStyle={{ backgroundColor:'#27303f', borderRadius:25, borderTopColor:'#27303f', marginLeft:12, marginRight:12, marginBottom:5 }}
                        textInputStyle={{color:"#fff"}}
                    />
                }}
            />
        </View>
    )
}

export default Chat

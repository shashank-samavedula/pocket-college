import React, { useState } from 'react';
import { View, Text, Button, StyleSheet, StatusBar, TextInput, TouchableOpacity, Alert } from 'react-native';
import auth from '@react-native-firebase/auth';
import firestore from '@react-native-firebase/firestore';

const Register = ({ navigation }) => {
    const [progress, setProgress] = useState(1);
    const [user, setUser] = useState('HOD');
    const [userData, setUserData] = useState({
        name:'',
        email:'',
        phone:'',
        branch:'',
        user,
        sem:'',
        address:'',
        college:'',
        password:''
    });

    const signup = () => {

        const {name, phone, college, password, branch, sem, email, address} = userData
        if(name && phone && college && password && branch && (sem || user != 'Student') && email && address){

            auth()
            .createUserWithEmailAndPassword(email, password)
            .then(() => {
                console.log(name + " " + branch + " " + college + " " + phone + " " + user + " " + sem + " " + email + " " + address)
                
                if(user == 'Student'){
                    firestore()
                        .collection(college)
                        .doc(branch)
                        .collection(user)
                        .doc(sem)
                        .collection("Student-Data")
                        .doc(auth().currentUser.uid)
                        .set({
                            name:name,
                            phone:phone,
                            branch:branch,
                            userStatus: user,
                            sem: sem,
                            email:email,
                            address:address
                        })
                        .then(() => {
                            firestore()
                                .collection("Users")
                                .doc(auth().currentUser.uid)
                                .set({
                                    name:name,
                                    phone:phone,
                                    branch:branch,
                                    userStatus: user,
                                    sem: sem,
                                    email:email,
                                    college: college,
                                    userid:auth().currentUser.uid

                                })
                        })
                }
                else{
                    firestore()
                        .collection(college)
                        .doc(branch)
                        .collection(user)
                        .doc(auth().currentUser.uid)
                        .set({
                            name:name,
                            phone:phone,
                            branch:branch,
                            userStatus: user,
                            email:email,
                            address:address
                        })
                        .then(() => {
                            firestore()
                                .collection("Users")
                                .doc(auth().currentUser.uid)
                                .set({
                                    name:name,
                                    phone:phone,
                                    branch:branch,
                                    userStatus: user,
                                    email:email,
                                    college: college,
                                    userid:auth().currentUser.uid
                                })
                        })
                }
            })
            .catch(error => {
                if (error.code === 'auth/email-already-in-use') {
                    Alert.alert('That email address is already in use!');
                }
    
                if (error.code === 'auth/invalid-email') {
                    Alert.alert("This email address is invalid!");
                }
    
                console.log(error);
            });
        }
    }

    return (
        <View style={styles.container}>
            <StatusBar backgroundColor="#1d242f" />
            <View style={styles.boxWithShadow}>

                <View style={styles.heading}>
                    <Text style={{fontSize:25, color:'#009394', fontWeight:'bold'}}> {'<SignUp/>'} </Text>
                </View>

                {progress == 1 ? (
                    <View style={styles.progressBar}>
                        <View style={styles.circleFilled}>
                            <Text>1</Text>
                        </View>
                        <View style={{width:25, height:3, backgroundColor:'#0a0c10'}}></View>
                        <View style={styles.circle}>
                            <Text style={{color:'#a6a6a6'}}>2</Text>
                        </View>
                        <View style={{width:25, height:3, backgroundColor:'#0a0c10'}}></View>
                        <View style={styles.circle}>
                            <Text style={{color:'#a6a6a6'}}>3</Text>
                        </View>
                    </View>
                ) : (
                    <>
                    {progress == 2 ? (

                        <View style={styles.progressBar}>
                            <View style={styles.circleFilled}>
                                <Text>1</Text>
                            </View>
                            <View style={{width:25, height:3, backgroundColor:'#009394'}}></View>
                            <View style={styles.circleFilled}>
                                <Text>2</Text>
                            </View>
                            <View style={{width:25, height:3, backgroundColor:'#0a0c10'}}></View>
                            <View style={styles.circle}>
                                <Text style={{color:'#a6a6a6'}}>3</Text>
                            </View>
                        </View>
                    ) : (
                        <View style={styles.progressBar}>
                    <View style={styles.circleFilled}>
                        <Text>1</Text>
                    </View>
                    <View style={{width:25, height:3, backgroundColor:'#009394'}}></View>
                    <View style={styles.circleFilled}>
                        <Text>2</Text>
                    </View>
                    <View style={{width:25, height:3, backgroundColor:'#009394'}}></View>
                    <View style={styles.circleFilled}>
                        <Text>3</Text>
                    </View>
                </View>
                    )}
                    </>
                )}
        
                {progress == 1 ? (
                    <View style={styles.inputBox}>
                        <TextInput placeholder="Name" placeholderTextColor="#a6a6a6" style={styles.input} value={userData.name} onChangeText={(txt) => setUserData({...userData, name:txt})} />
                        <TextInput placeholder="Email" placeholderTextColor="#a6a6a6" style={styles.input} value={userData.email} onChangeText={(txt) => setUserData({...userData, email:txt})} />
                        <TextInput placeholder="Password" placeholderTextColor="#a6a6a6" style={styles.input} value={userData.password} onChangeText={(txt) => setUserData({...userData, password:txt})} />
                    </View>
                ) : (
                    <>
                    {progress == 2 ? (
                    <View style={styles.inputBox}>
                        <TextInput placeholder="Phone" placeholderTextColor="#a6a6a6" style={styles.input} value={userData.phone} onChangeText={(txt) => setUserData({...userData, phone:txt})} />
                        <TextInput placeholder="Branch" placeholderTextColor="#a6a6a6" style={styles.input} value={userData.branch} onChangeText={(txt) => setUserData({...userData, branch:txt})} />


                        <View style={{flexDirection:'row', marginVertical:10, backgroundColor:'#0a0c10', justifyContent:'space-evenly',alignItems:'center', height:50, borderRadius:20}}>
                            <TouchableOpacity style={{backgroundColor: (user == 'HOD') ? '#009394' : '#0a0c10', width:80, alignItems:'center', borderRadius:10}}
                                onPress={() => setUser('HOD')}>
                            <Text style={{color: (user == 'HOD') ? '#131820' : 'white', fontWeight:'bold'}}>HOD</Text>
                            </TouchableOpacity>
                            <TouchableOpacity style={{backgroundColor: (user == 'Teacher') ? '#009394' : '#0a0c10', width:80, alignItems:'center', borderRadius:10}}
                                onPress={() => setUser('Teacher')}>
                            <Text style={{color: (user == 'Teacher') ? '#131820' : 'white', fontWeight:'bold'}}>Teacher</Text>
                            </TouchableOpacity>
                            <TouchableOpacity style={{backgroundColor: (user == 'Student') ? '#009394' : '#0a0c10', width:80, alignItems:'center', borderRadius:10}}
                                onPress={() => setUser('Student')}>
                            <Text style={{color: (user == 'Student') ? '#131820' : 'white', fontWeight:'bold'}}>Student</Text>
                            </TouchableOpacity>
                        </View>
                    
                    </View>
                    ) : (
                        <View style={styles.inputBox}>
                            <TextInput placeholder="Sem" placeholderTextColor="#a6a6a6" style={styles.input} value={userData.sem} onChangeText={(txt) => setUserData({...userData, sem:txt})}/>
                            <TextInput placeholder="Address" placeholderTextColor="#a6a6a6" style={styles.input} value={userData.address} onChangeText={(txt) => setUserData({...userData, address:txt})} />
                            <TextInput placeholder="College" placeholderTextColor="#a6a6a6" style={styles.input} value={userData.college} onChangeText={(txt) => setUserData({...userData, college:txt})} />
                        </View>
                    )}
                    </>
                )}


                <View style={styles.btnContainer}>

                    {progress > 1 ? (
                        <TouchableOpacity style={styles.prevBtn} onPress={() => setProgress(progress - 1)}>
                            <Text style={{fontWeight:'bold', color:'#a6a6a6'}}>Prev</Text>
                        </TouchableOpacity>
                    ) : null}

                    {progress < 3 ? (
                        <TouchableOpacity style={styles.btn} onPress={() => setProgress(progress + 1)}>
                            <Text style={{fontWeight:'bold', color:'#131820'}}>Next</Text>
                        </TouchableOpacity>
                    ) : (
                        <TouchableOpacity style={styles.btn} onPress={() => signup()}>
                            <Text style={{fontWeight:'bold', color:'#131820'}}>Done</Text>
                        </TouchableOpacity>
                    )}

                </View>
            </View>
            
            {/* <Button title="Go to Login" onPress={() => navigation.navigate('Login')} /> */}
        </View>
    )
}

const styles = StyleSheet.create({
    // backgroundColor:'#131820',

    container: {
        flex:1,
        backgroundColor:'#1d242f',
        justifyContent:'center',
        alignItems:'center'
    },
    boxWithShadow: {
        /* shadowColor: '#009394',
        elevation: 20, */
        width:350,
        backgroundColor:'#131820',
        borderRadius:20,
        alignItems:'center'
    },
    input: {
        width:320,
        height:50,
        borderRadius:15,
        paddingLeft:20,
        color:'white',
        marginVertical:10,
        backgroundColor:'#0a0c10'
    },
    inputBox: {
        marginVertical:20
    },
    progressBar: {
        flexDirection:'row',
        alignItems:'center',
        marginTop:20
    },
    circleFilled:{
        width:30,
        height:30,
        backgroundColor:'#009394',
        justifyContent:'center',
        alignItems:'center',
        borderRadius:15
    },
    circle: {
        width:30,
        height:30,
        backgroundColor:'#0a0c10',
        justifyContent:'center',
        alignItems:'center',
        borderRadius:15
    },
    prevBtn: {
        width:100,
        height:50,
        backgroundColor:'#0a0c10',
        margin:5,
        borderRadius:30,
        justifyContent:'center',
        alignItems:'center'
    },
    btn: {
        width:100,
        height:50,
        backgroundColor:'#009394',
        margin:5,
        borderRadius:30,
        justifyContent:'center',
        alignItems:'center'
    },
    btnContainer: {
        flexDirection:'row',
        marginBottom:20
    },
    heading: {
        width:350,
        height:60,
        backgroundColor:'#0a0c10',
        borderTopLeftRadius:20,
        borderTopRightRadius:20,
        justifyContent:'center',
        alignItems:'center'
    }
})

export default Register
